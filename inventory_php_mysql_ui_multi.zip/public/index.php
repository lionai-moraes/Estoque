<?php require_once 'require_login.php'; ?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Autopeças — Estoque</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
      <div class="container">
        <a class="navbar-brand fw-semibold" href="#">Autopeças • Estoque</a>
        <div class="text-white ms-auto small">
          <?php echo htmlspecialchars($AUTH_USER_NAME); ?> &nbsp;
          <a class="btn btn-sm btn-outline-light" href="../auth_logout.php">Sair</a>
        </div>
      </div>
    </nav>
    <div class="container">
      <div class="alert alert-info">Interface pronta. Use as abas e cadastre seus produtos.</div>
    </div>
  </body>
</html>
